class PagesController < ApplicationController
  def About_us
  end

  def Product
  end

  def Contact_us
  end
end
